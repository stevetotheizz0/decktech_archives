Extract these files into the deckmaker directory and delete the file
"SWCCG Cards.dm".

cu, Bee-Rockxs