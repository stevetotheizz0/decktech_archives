How to play LOTR on Apprentice

1) Create Deck - under file - Deckmaker...a popup utility will appear. Create a deck and hit save (the little disk icon)

2) Either play solitare or connect to opponent over the internet

3) Before drawing your hand you need to do the following
	a) go to the menu and select ACTION - CREATE A CARD
	b) the title of the card is BID - in the power section place your opening bid - and hit ok
	c) when you see your opponent has completed making his card both players should drag their cards onto the table.
	d) then go to menu VIEW - MY LIBRARY
	e) while holding the shift key down - drag each of your sites onto the table (I would keep them in some order). this will drag the cards upside down on the table
	f) then drag frodo, the one ring, and your starting fellowship
	g) close your library and CTRL-S to shuffle
	h) draw 8 card CTRL-D or click the draw button 8 times
	i) go to the menu and select ACTION - CREATE A CARD..titled TWILIGHT with nothing in power/toughness
	j) place that card on the table

4) keep track of counters but right clicking on a card a hitting D to add one or C to set the number on coutners

5) keep track of twilight by placing counters on the TWILIGHT card. Have the opponent take control of card anytime they need to play something - or just do it yourself.

HAVE FUN
